window.onload = function () {
    form.style.display = 'none';
    bform.style.display = 'none';
}

/*==================== SHOW MENU ====================*/
const showMenu = (toggleId, navId) => {
    const toggle = document.getElementById(toggleId),
        nav = document.getElementById(navId)

    if (toggle && nav) {
        toggle.addEventListener('click', () => {
            nav.classList.toggle('show-menu')
        })
    }
}
showMenu('nav-toggle', 'nav-menu')

/*==================== SHOW SCROLL TOP ====================*/
function scrollTop() {
    const scrollTop = document.getElementById('scroll-top');
    if (this.scrollY >= 360) {
        scrollTop.classList.add('show-scroll');
    }
    else {
        scrollTop.classList.remove('show-scroll')
    }
}
window.addEventListener('scroll', scrollTop)
// *==================show or hide form==================*/
let form = document.querySelector('.form');
document.querySelector('#cont-btn').onclick = function () {
    if (form.style.display != 'none') {
        form.style.display = 'none';
    }
    else {
        form.style.display = 'block';
    }
}

document.querySelector("#close").onclick = function () {
    if (form.style.display = 'block') {
        form.style.display = 'none';
    }
}

// ===============BOOK FORM==========================*/
let bform = document.querySelector('#b-form');
document.querySelector('#book_now').onclick = function () {

    if (bform.style.display != 'none') {
        bform.style.display = 'none';
    }
    else {
        bform.style.display = 'block';
    }
}
document.querySelector("#close2").onclick = function () {
    if (bform.style.display = 'block') {
        bform.style.display = 'none';
    }
}


// ===================end here================================*/

/*==================== SCROLL REVEAL ANIMATION ====================*/
let sa = ScrollReveal({
    origin: 'left',
    distance: '30px',
    duration: 2000,
    reset: true
});

sa.reveal(`.home__data, .home__img, .about__data, .about__img, .services__content, 
.menu__content,.app__data, .app__img,.contact__data, .contact__button,.footer__content`, {
    interval: 200
})
